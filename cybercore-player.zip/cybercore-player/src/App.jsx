export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center text-white">
      <h1 className="text-4xl font-bold">CyberCore Player Ready 🚀</h1>
    </div>
  )
}
